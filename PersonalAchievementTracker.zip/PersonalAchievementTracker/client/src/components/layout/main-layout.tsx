import { ReactNode } from "react";
import Header from "./header";
import { Helmet } from "react-helmet";

interface MainLayoutProps {
  children: ReactNode;
  title?: string;
}

export default function MainLayout({ children, title }: MainLayoutProps) {
  const pageTitle = title ? `${title} - AirdropHub` : "AirdropHub";
  
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>{pageTitle}</title>
      </Helmet>
      <Header />
      <main className="flex-1 container mx-auto py-6 px-4 md:px-6">
        {children}
      </main>
    </div>
  );
}