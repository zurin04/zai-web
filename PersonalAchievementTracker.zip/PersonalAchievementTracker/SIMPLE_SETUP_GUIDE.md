# Easy VPS Setup Guide

## Step 1: Upload Files to Your VPS

```bash
# Upload your project files to your VPS
scp -r crypto-airdrop-platform/ root@your-vps-ip:/tmp/
```

## Step 2: Run Installation Script

```bash
# SSH into your VPS
ssh root@your-vps-ip

# Navigate to uploaded files
cd /tmp/crypto-airdrop-platform

# Make install script executable
chmod +x install.sh

# Run the main installation script
./install.sh
```

**That's it!** The `install.sh` script will automatically:
- ✅ Install Node.js 20
- ✅ Install PM2 process manager
- ✅ Install Nginx web server
- ✅ Install PostgreSQL database
- ✅ Set up application files
- ✅ Configure security (firewall)
- ✅ Create database and add sample data
- ✅ Start the application

## Step 3: Configure Your Domain (Optional)

If you have a domain name:

```bash
# Edit nginx configuration
nano /etc/nginx/sites-available/crypto-airdrop

# Replace 'your-domain.com' with your actual domain
# Save and exit (Ctrl+X, Y, Enter)

# Reload nginx
systemctl reload nginx
```

## Step 4: Setup SSL Certificate (Recommended)

```bash
cd /var/www/crypto-airdrop
./setup-ssl.sh

# Follow instructions to run:
certbot --nginx -d yourdomain.com
```

## Quick Check

```bash
# Check if application is running
pm2 status

# Check nginx status
systemctl status nginx

# View application logs
pm2 logs crypto-airdrop
```

Your crypto airdrop platform will be available at:
- **With domain**: `https://yourdomain.com`
- **Without domain**: `http://your-vps-ip`

## Default Login Credentials

- **Admin**: username `admin`, password `admin123`
- **Demo User**: username `demo`, password `demo123`

## Common Issues

If something goes wrong:
- Check logs: `pm2 logs crypto-airdrop`
- Restart app: `pm2 restart crypto-airdrop`
- Check nginx: `systemctl status nginx`
- Database issues: `systemctl status postgresql`

## Important Files

- **DO NOT use** `vps-setup.sh` - this is outdated
- **USE** `install.sh` - this is the current installation script
- Application files will be in `/var/www/crypto-airdrop/`