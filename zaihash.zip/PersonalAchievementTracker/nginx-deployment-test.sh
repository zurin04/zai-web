#!/bin/bash

# Test script for nginx deployment system
# Validates all components are working correctly

echo "=== Testing Nginx Deployment Setup ==="

# Test 1: Verify installation script syntax
echo "1. Checking installation script..."
if bash -n install.sh; then
    echo "   ✓ Installation script syntax valid"
else
    echo "   ✗ Installation script has syntax errors"
    exit 1
fi

# Test 2: Check required files exist
echo "2. Checking deployment files..."
required_files=("install.sh" "monitor.sh" "start-app.sh" ".env.example" "QUICKSTART.md" "INSTALL_GUIDE.md" "PRODUCTION_DEPLOYMENT.md")
for file in "${required_files[@]}"; do
    if [[ -f "$file" ]]; then
        echo "   ✓ $file exists"
    else
        echo "   ✗ $file missing"
        exit 1
    fi
done

# Test 3: Verify nginx configuration template
echo "3. Checking nginx configuration..."
if grep -q "proxy_pass.*localhost:3000" install.sh; then
    echo "   ✓ Nginx proxy configuration present"
else
    echo "   ✗ Nginx proxy configuration missing"
    exit 1
fi

if grep -q "location /ws" install.sh; then
    echo "   ✓ WebSocket configuration present"
else
    echo "   ✗ WebSocket configuration missing"
    exit 1
fi

# Test 4: Check security features
echo "4. Checking security features..."
if grep -q "fail2ban" install.sh; then
    echo "   ✓ Fail2ban protection included"
else
    echo "   ✗ Fail2ban protection missing"
fi

if grep -q "ufw.*enable" install.sh; then
    echo "   ✓ Firewall configuration included"
else
    echo "   ✗ Firewall configuration missing"
fi

# Test 5: Verify SSL setup
echo "5. Checking SSL configuration..."
if grep -q "certbot.*nginx" install.sh; then
    echo "   ✓ SSL certificate setup included"
else
    echo "   ✗ SSL certificate setup missing"
fi

# Test 6: Check backup system
echo "6. Checking backup system..."
if grep -q "backup.sh" install.sh; then
    echo "   ✓ Backup script generation included"
else
    echo "   ✗ Backup script generation missing"
fi

# Test 7: Verify monitoring
echo "7. Checking monitoring capabilities..."
if [[ -f "monitor.sh" ]]; then
    echo "   ✓ System monitoring script available"
else
    echo "   ✗ System monitoring script missing"
fi

# Test 8: Check PM2 configuration
echo "8. Checking PM2 configuration..."
if grep -q "ecosystem.config.js" install.sh; then
    echo "   ✓ PM2 configuration included"
else
    echo "   ✗ PM2 configuration missing"
fi

echo ""
echo "=== Test Summary ==="
echo "All nginx deployment components verified successfully!"
echo ""
echo "Deployment features included:"
echo "  • One-command installation"
echo "  • Nginx with SSL support" 
echo "  • Security hardening (firewall, fail2ban)"
echo "  • Automated backups"
echo "  • System monitoring"
echo "  • PM2 process management"
echo "  • Production optimizations"
echo ""
echo "Ready for VPS deployment!"