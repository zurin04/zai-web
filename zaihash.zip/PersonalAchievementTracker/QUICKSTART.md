# Quick Start Guide

## Easy VPS Setup with Nginx

### Step 1: Upload and Install
```bash
# Copy files to your VPS
scp -r . root@your-vps-ip:/tmp/crypto-airdrop/

# SSH to your VPS
ssh root@your-vps-ip

# Run installation
cd /tmp/crypto-airdrop
chmod +x install.sh
./install.sh
```

### Step 2: Configure Domain
```bash
# Edit nginx config
nano /etc/nginx/sites-available/crypto-airdrop

# Replace 'your-domain.com' with your actual domain
# Save and exit (Ctrl+X, Y, Enter)

# Reload nginx
systemctl reload nginx
```

### Step 3: Setup SSL (Optional but Recommended)
```bash
cd /var/www/crypto-airdrop
./setup-ssl.sh

# Follow the instructions to run:
# certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

### Step 4: Verify Installation
```bash
# Check application status
pm2 status

# Check nginx status
systemctl status nginx

# View logs if needed
pm2 logs crypto-airdrop
```

## That's it! 

Your crypto airdrop platform is now running with:
- Professional nginx configuration
- SSL certificate support
- Automatic backups
- Process monitoring with PM2
- Optimized performance settings

Access your site at: `https://yourdomain.com`

## Need Help?

- **Application issues**: `pm2 logs crypto-airdrop`
- **Server issues**: `systemctl status nginx`
- **Update app**: `./update.sh`
- **Backup data**: `./backup.sh`

See `INSTALL_GUIDE.md` for detailed documentation.