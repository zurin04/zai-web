import React from "react";

interface ParticleBackgroundProps {
  className?: string;
}

export default function ParticleBackground({ className }: ParticleBackgroundProps) {
  return (
    <div className={`fixed inset-0 pointer-events-none z-0 ${className || ''}`}>
      {/* Create star elements using fixed elements */}
      <div className="stars absolute inset-0 overflow-hidden">
        {/* Static stars with glow effects */}
        {Array.from({ length: 50 }).map((_, i) => (
          <div 
            key={i}
            className="absolute rounded-full bg-white z-0"
            style={{
              width: Math.random() * 2 + 1 + 'px',
              height: Math.random() * 2 + 1 + 'px',
              top: Math.random() * 100 + '%',
              left: Math.random() * 100 + '%',
              opacity: Math.random() * 0.5 + 0.2,
              boxShadow: `0 0 ${Math.random() * 10 + 2}px rgba(255, 255, 255, 0.7)`,
              animation: `twinkle ${Math.random() * 5 + 3}s infinite ${Math.random() * 5}s`
            }}
          />
        ))}
        
        {/* Colorful stars with different colors for crypto vibes */}
        {Array.from({ length: 15 }).map((_, i) => {
          const colors = ['#3b82f6', '#8b5cf6', '#ec4899', '#10b981', '#f59e0b'];
          const randomColor = colors[Math.floor(Math.random() * colors.length)];
          return (
            <div 
              key={`color-${i}`}
              className="absolute rounded-full z-0"
              style={{
                backgroundColor: randomColor,
                width: Math.random() * 3 + 1 + 'px',
                height: Math.random() * 3 + 1 + 'px',
                top: Math.random() * 100 + '%',
                left: Math.random() * 100 + '%',
                opacity: Math.random() * 0.6 + 0.4,
                boxShadow: `0 0 ${Math.random() * 8 + 4}px ${randomColor}`,
                animation: `twinkle ${Math.random() * 6 + 3}s infinite ${Math.random() * 5}s`
              }}
            />
          );
        })}
        
        {/* Shooting stars/particles */}
        {Array.from({ length: 5 }).map((_, i) => (
          <div 
            key={`shooting-${i}`}
            className="absolute bg-white z-0"
            style={{
              width: '2px',
              height: '2px',
              top: Math.random() * 80 + '%',
              left: Math.random() * 80 + '%',
              opacity: 0,
              boxShadow: '0 0 4px 2px rgba(255, 255, 255, 0.7)',
              animation: `shooting ${Math.random() * 10 + 10}s linear infinite ${Math.random() * 15}s`
            }}
          />
        ))}
      </div>
      
      {/* Add nebula-like glow areas for depth */}
      <div className="absolute top-0 left-1/4 w-1/2 h-1/3 bg-purple-500/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-1/4 w-2/3 h-1/3 bg-blue-500/5 rounded-full blur-3xl"></div>
      <div className="absolute top-1/3 right-0 w-1/3 h-1/2 bg-pink-500/5 rounded-full blur-3xl"></div>
    </div>
  );
}