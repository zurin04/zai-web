# Production Deployment Guide

## Complete VPS Setup with Nginx

### Prerequisites
- Ubuntu/Debian VPS (2GB+ RAM recommended)
- Root access or sudo privileges
- Domain name pointed to your server IP

### Quick Deployment

1. **Upload Project**
```bash
# Using SCP
scp -r crypto-airdrop-platform/ root@your-server-ip:/tmp/

# Or using Git
git clone https://github.com/your-repo/crypto-airdrop-platform.git /tmp/crypto-airdrop-platform
```

2. **Run Installation**
```bash
ssh root@your-server-ip
cd /tmp/crypto-airdrop-platform
chmod +x install.sh
./install.sh
```

The installation script automatically:
- Installs Node.js 20, PM2, Nginx, PostgreSQL
- Sets up security hardening (UFW firewall, fail2ban)
- Configures optimized nginx with SSL preparation
- Creates database and seeds initial data
- Sets up automated backups and monitoring

### Post-Installation Configuration

#### 1. Domain Configuration
```bash
nano /etc/nginx/sites-available/crypto-airdrop
# Replace 'your-domain.com' with your actual domain
systemctl reload nginx
```

#### 2. SSL Certificate Setup
```bash
cd /var/www/crypto-airdrop
./setup-ssl.sh
# Follow instructions to run certbot
```

#### 3. Environment Configuration
```bash
nano /var/www/crypto-airdrop/.env
# Update database credentials and other settings
pm2 restart crypto-airdrop
```

### Server Management

#### Application Commands
```bash
pm2 status                    # Check status
pm2 restart crypto-airdrop    # Restart app
pm2 logs crypto-airdrop       # View logs
pm2 monit                     # Resource monitor
```

#### Nginx Commands
```bash
systemctl status nginx        # Check nginx
nginx -t                      # Test configuration
systemctl reload nginx        # Reload config
```

#### Database Commands
```bash
sudo -u postgres psql crypto_airdrop    # Access database
cd /var/www/crypto-airdrop && npm run db:push    # Run migrations
```

### Monitoring and Maintenance

#### Health Check
```bash
cd /var/www/crypto-airdrop
chmod +x monitor.sh
./monitor.sh
```

#### Backups
```bash
./backup.sh                   # Manual backup
ls -la /var/backups/crypto-airdrop/    # View backups
```

#### Updates
```bash
./update.sh                   # Update application
```

### Performance Optimization

#### Nginx Configuration Features
- Gzip compression enabled
- Browser caching for static assets
- Rate limiting for API endpoints
- WebSocket support for real-time features
- Security headers (XSS protection, CSRF prevention)

#### PM2 Configuration
- Automatic restart on crashes
- Memory usage monitoring
- Log rotation
- Cluster mode ready for scaling

### Security Features

#### Firewall (UFW)
- SSH (port 22) - allowed
- HTTP (port 80) - allowed
- HTTPS (port 443) - allowed
- All other ports - denied

#### Fail2ban Protection
- Nginx HTTP auth protection
- DOS attack prevention
- Automatic IP banning

#### SSL/TLS
- Let's Encrypt certificates
- Automatic renewal setup
- HTTPS redirect configuration

### Troubleshooting

#### Application Not Starting
```bash
pm2 logs crypto-airdrop --lines 50
# Check environment variables in .env
# Verify database connection
```

#### Nginx Issues
```bash
nginx -t                      # Test configuration
tail -f /var/log/nginx/error.log    # Check errors
systemctl status nginx       # Check service status
```

#### Database Problems
```bash
sudo -u postgres psql -c "SELECT version();"    # Test connection
systemctl status postgresql  # Check PostgreSQL status
```

#### SSL Certificate Issues
```bash
certbot certificates         # Check certificate status
certbot renew --dry-run      # Test renewal process
```

### File Locations

- **Application**: `/var/www/crypto-airdrop/`
- **Nginx Config**: `/etc/nginx/sites-available/crypto-airdrop`
- **SSL Certificates**: `/etc/letsencrypt/live/yourdomain.com/`
- **Logs**: `/var/log/nginx/` and PM2 logs
- **Backups**: `/var/backups/crypto-airdrop/`
- **Environment**: `/var/www/crypto-airdrop/.env`

### Scaling and Performance

#### For High Traffic
1. Enable PM2 cluster mode
2. Add Redis for session storage
3. Implement CDN for static assets
4. Database query optimization
5. Load balancer configuration

#### Resource Monitoring
```bash
./monitor.sh                 # System health check
pm2 monit                    # PM2 dashboard
htop                         # System resources
```

### Support and Maintenance

#### Regular Tasks
- Monitor disk space and logs
- Check SSL certificate expiry
- Review security logs
- Update system packages
- Test backup restoration

#### Emergency Recovery
```bash
# Restore from backup
cd /var/backups/crypto-airdrop/
sudo -u postgres psql crypto_airdrop < database_YYYYMMDD_HHMMSS.sql

# Restore uploads
tar -xzf uploads_YYYYMMDD_HHMMSS.tar.gz -C /var/www/crypto-airdrop/public/
```

This deployment setup provides a production-ready crypto airdrop platform with enterprise-level security, monitoring, and maintenance capabilities.