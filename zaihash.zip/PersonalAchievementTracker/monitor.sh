#!/bin/bash

# Crypto Airdrop Platform - System Monitoring Script
# Checks health of all services and generates status report

set -e

APP_DIR="/var/www/crypto-airdrop"
LOG_FILE="/var/log/crypto-airdrop-monitor.log"

echo "=== System Health Check $(date) ===" | tee -a $LOG_FILE

# Function to check service status
check_service() {
    local service=$1
    if systemctl is-active --quiet $service; then
        echo "✅ $service: Running" | tee -a $LOG_FILE
        return 0
    else
        echo "❌ $service: Not running" | tee -a $LOG_FILE
        return 1
    fi
}

# Function to check PM2 application
check_pm2_app() {
    local app_name=$1
    local status=$(pm2 jlist | jq -r ".[] | select(.name==\"$app_name\") | .pm2_env.status" 2>/dev/null)
    
    if [ "$status" = "online" ]; then
        echo "✅ PM2 $app_name: Online" | tee -a $LOG_FILE
        return 0
    else
        echo "❌ PM2 $app_name: Offline" | tee -a $LOG_FILE
        return 1
    fi
}

# Function to check disk space
check_disk_space() {
    local usage=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
    echo "💾 Disk Usage: ${usage}%" | tee -a $LOG_FILE
    
    if [ $usage -gt 80 ]; then
        echo "⚠️  Warning: Disk usage above 80%" | tee -a $LOG_FILE
        return 1
    fi
    return 0
}

# Function to check memory usage
check_memory() {
    local mem_usage=$(free | grep Mem | awk '{printf("%.1f", $3/$2 * 100.0)}')
    echo "🧠 Memory Usage: ${mem_usage}%" | tee -a $LOG_FILE
    
    if (( $(echo "$mem_usage > 85" | bc -l) )); then
        echo "⚠️  Warning: Memory usage above 85%" | tee -a $LOG_FILE
        return 1
    fi
    return 0
}

# Function to check SSL certificate expiry
check_ssl_cert() {
    local domain=$1
    if [ -z "$domain" ]; then
        echo "ℹ️  SSL: No domain configured for check" | tee -a $LOG_FILE
        return 0
    fi
    
    local cert_file="/etc/letsencrypt/live/$domain/cert.pem"
    if [ -f "$cert_file" ]; then
        local expiry_date=$(openssl x509 -enddate -noout -in "$cert_file" | cut -d= -f2)
        local expiry_epoch=$(date -d "$expiry_date" +%s)
        local current_epoch=$(date +%s)
        local days_until_expiry=$(( (expiry_epoch - current_epoch) / 86400 ))
        
        echo "🔒 SSL Certificate: $days_until_expiry days until expiry" | tee -a $LOG_FILE
        
        if [ $days_until_expiry -lt 7 ]; then
            echo "⚠️  Warning: SSL certificate expires in less than 7 days" | tee -a $LOG_FILE
            return 1
        fi
    else
        echo "ℹ️  SSL: No certificate found" | tee -a $LOG_FILE
    fi
    return 0
}

# Function to check database connectivity
check_database() {
    cd $APP_DIR
    if sudo -u postgres psql -d crypto_airdrop -c "SELECT 1;" >/dev/null 2>&1; then
        echo "✅ Database: Connected" | tee -a $LOG_FILE
        return 0
    else
        echo "❌ Database: Connection failed" | tee -a $LOG_FILE
        return 1
    fi
}

# Function to check nginx configuration
check_nginx_config() {
    if nginx -t >/dev/null 2>&1; then
        echo "✅ Nginx Config: Valid" | tee -a $LOG_FILE
        return 0
    else
        echo "❌ Nginx Config: Invalid" | tee -a $LOG_FILE
        return 1
    fi
}

# Function to check log file sizes
check_log_sizes() {
    local nginx_access_size=$(stat -c%s "/var/log/nginx/access.log" 2>/dev/null || echo 0)
    local nginx_error_size=$(stat -c%s "/var/log/nginx/error.log" 2>/dev/null || echo 0)
    
    # Convert to MB
    nginx_access_mb=$((nginx_access_size / 1024 / 1024))
    nginx_error_mb=$((nginx_error_size / 1024 / 1024))
    
    echo "📝 Nginx Access Log: ${nginx_access_mb}MB" | tee -a $LOG_FILE
    echo "📝 Nginx Error Log: ${nginx_error_mb}MB" | tee -a $LOG_FILE
    
    if [ $nginx_access_mb -gt 100 ] || [ $nginx_error_mb -gt 100 ]; then
        echo "ℹ️  Note: Large log files detected. Consider log rotation." | tee -a $LOG_FILE
    fi
}

# Main health check
main() {
    local issues=0
    
    echo "Checking core services..."
    check_service "nginx" || ((issues++))
    check_service "postgresql" || ((issues++))
    check_service "fail2ban" || ((issues++))
    
    echo -e "\nChecking application..."
    check_pm2_app "crypto-airdrop" || ((issues++))
    
    echo -e "\nChecking system resources..."
    check_disk_space || ((issues++))
    check_memory || ((issues++))
    
    echo -e "\nChecking configuration..."
    check_nginx_config || ((issues++))
    check_database || ((issues++))
    
    echo -e "\nChecking security..."
    # Extract domain from nginx config if available
    local domain=$(grep -oP 'server_name \K[^;]*' /etc/nginx/sites-available/crypto-airdrop 2>/dev/null | awk '{print $1}' | grep -v your-domain.com || echo "")
    check_ssl_cert "$domain" || ((issues++))
    
    echo -e "\nChecking logs..."
    check_log_sizes
    
    echo -e "\n=== Summary ===" | tee -a $LOG_FILE
    if [ $issues -eq 0 ]; then
        echo "🎉 All systems operational!" | tee -a $LOG_FILE
    else
        echo "⚠️  Found $issues issue(s) that need attention" | tee -a $LOG_FILE
    fi
    
    echo "Report saved to: $LOG_FILE"
    
    return $issues
}

# Run health check
main "$@"