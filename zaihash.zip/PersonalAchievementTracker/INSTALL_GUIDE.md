# VPS Installation Guide - Nginx Setup

## Quick Installation

### Prerequisites
- Ubuntu/Debian VPS with root access
- Domain name pointed to your VPS IP address

### One-Command Installation

1. **Upload project files to your VPS**
   ```bash
   scp -r crypto-airdrop-platform/ root@your-vps-ip:/tmp/
   ```

2. **Run the installation script**
   ```bash
   ssh root@your-vps-ip
   cd /tmp/crypto-airdrop-platform
   chmod +x install.sh
   ./install.sh
   ```

The script automatically installs:
- ✅ Node.js 20
- ✅ PM2 Process Manager
- ✅ Nginx Web Server
- ✅ PostgreSQL Database
- ✅ Application Dependencies
- ✅ Automated Backups

## Post-Installation Setup

### 1. Configure Your Domain

Edit the nginx configuration:
```bash
nano /etc/nginx/sites-available/crypto-airdrop
```

Replace `your-domain.com` with your actual domain name, then reload nginx:
```bash
systemctl reload nginx
```

### 2. Setup SSL Certificate (Recommended)

Run the SSL setup script:
```bash
cd /var/www/crypto-airdrop
./setup-ssl.sh
```

Then execute the certbot command with your domain:
```bash
certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

### 3. Configure Environment Variables

Create your environment file:
```bash
cd /var/www/crypto-airdrop
cp .env.example .env
nano .env
```

Update the database URL and other settings as needed.

## Management Commands

### Application Management
```bash
# Check application status
pm2 status

# Restart application
pm2 restart crypto-airdrop

# View application logs
pm2 logs crypto-airdrop

# Monitor resources
pm2 monit
```

### Nginx Management
```bash
# Check nginx status
systemctl status nginx

# Test nginx configuration
nginx -t

# Reload nginx (after config changes)
systemctl reload nginx

# Restart nginx
systemctl restart nginx
```

### Database Management
```bash
# Access PostgreSQL
sudo -u postgres psql crypto_airdrop

# Run database migrations
cd /var/www/crypto-airdrop
npm run db:push

# Seed database with sample data
npm run db:seed
```

### Updates and Backups
```bash
# Update application
./update.sh

# Create manual backup
./backup.sh

# View backup files
ls -la /var/backups/crypto-airdrop/
```

## File Locations

- **Application**: `/var/www/crypto-airdrop/`
- **Nginx Config**: `/etc/nginx/sites-available/crypto-airdrop`
- **Logs**: `/var/log/nginx/` and `pm2 logs`
- **Backups**: `/var/backups/crypto-airdrop/`
- **SSL Certificates**: `/etc/letsencrypt/live/yourdomain.com/`

## Troubleshooting

### Check Application Status
```bash
pm2 status
pm2 logs crypto-airdrop --lines 50
```

### Check Nginx Status
```bash
systemctl status nginx
nginx -t
tail -f /var/log/nginx/error.log
```

### Check Database Connection
```bash
sudo -u postgres psql -c "SELECT version();"
```

### Common Issues

1. **Application won't start**: Check environment variables in `.env`
2. **Database connection fails**: Verify DATABASE_URL in `.env`
3. **Nginx errors**: Run `nginx -t` to check configuration
4. **SSL issues**: Check certbot logs and certificate validity

## Security Checklist

- ✅ Change default database password
- ✅ Setup SSL certificate
- ✅ Configure firewall rules
- ✅ Enable automatic backups
- ✅ Keep system updated
- ✅ Monitor application logs

## Firewall Configuration

```bash
# Enable UFW firewall
ufw enable

# Allow SSH, HTTP, and HTTPS
ufw allow ssh
ufw allow 80
ufw allow 443

# Check firewall status
ufw status
```

## Performance Optimization

The nginx configuration includes:
- Gzip compression
- Static file caching
- Rate limiting for API endpoints
- WebSocket support for real-time features

For high-traffic sites, consider:
- Adding Redis for session storage
- Implementing CDN for static assets
- Database query optimization
- PM2 cluster mode for multiple instances