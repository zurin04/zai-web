# Crypto Airdrop Platform

A comprehensive cryptocurrency learning and engagement platform that enables users to explore, learn, and participate in cryptocurrency ecosystems through advanced user management, creator workflows, and Web3 integration.

## Features

- **User Authentication**: Traditional login/register and Web3 wallet integration
- **Airdrop Management**: Browse, save, and track cryptocurrency airdrops
- **Creator System**: Apply to become a creator and manage airdrop listings
- **Admin Panel**: Comprehensive administration tools
- **Real-time Chat**: Global chat system with WebSocket support
- **Crypto Prices**: Live cryptocurrency price tracking
- **Role-based Access**: User, Creator, and Admin permission levels

## Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, Shadcn/UI
- **Backend**: Node.js, Express, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Passport.js, SIWE (Sign-In with Ethereum)
- **Real-time**: WebSocket for chat functionality
- **Build**: Vite, ESBuild

## VPS Installation with Nginx

### Prerequisites

- Ubuntu/Debian VPS with root access
- Domain name pointed to your VPS IP address

### One-Command Installation

1. Upload project files to your VPS:
```bash
scp -r crypto-airdrop-platform/ root@your-vps-ip:/tmp/
```

2. Run the installation script:
```bash
ssh root@your-vps-ip
cd /tmp/crypto-airdrop-platform
chmod +x install.sh
./install.sh
```

The script automatically installs:
- Node.js 20 and PM2 process manager
- Nginx web server with optimized configuration  
- PostgreSQL database
- Application dependencies and build
- Automated backup system

### Post-Installation Setup

1. **Configure your domain**:
```bash
nano /etc/nginx/sites-available/crypto-airdrop
# Replace 'your-domain.com' with your actual domain
systemctl reload nginx
```

2. **Setup SSL certificate**:
```bash
cd /var/www/crypto-airdrop
./setup-ssl.sh
# Then run: certbot --nginx -d yourdomain.com
```

3. **Configure environment variables**:
```bash
cp .env.example .env
nano .env
```

## Server Management

### Application Commands
```bash
pm2 status                    # Check application status
pm2 restart crypto-airdrop    # Restart application
pm2 logs crypto-airdrop       # View logs
pm2 monit                     # Monitor resources
```

### Nginx Commands
```bash
systemctl status nginx        # Check nginx status
nginx -t                      # Test configuration
systemctl reload nginx        # Reload after config changes
tail -f /var/log/nginx/error.log  # View error logs
```

### Database Management
```bash
# Access PostgreSQL
sudo -u postgres psql crypto_airdrop

# Run database migrations
cd /var/www/crypto-airdrop
npm run db:push

# Seed database with sample data
npm run db:seed
```

### Maintenance
```bash
cd /var/www/crypto-airdrop
./update.sh     # Update application
./backup.sh     # Create manual backup
```

Daily automated backups run at 2 AM via cron job.

## Nginx Deployment Features

### Security & Performance
- **Gzip Compression**: Automatic compression for faster page loads
- **Rate Limiting**: API endpoint protection against abuse
- **Security Headers**: XSS protection, frame options, content-type security
- **WebSocket Support**: Real-time chat functionality
- **Static File Optimization**: Efficient serving of uploads and assets

### SSL/HTTPS Ready
- **Let's Encrypt Integration**: Free SSL certificate automation
- **HTTPS Redirect**: Automatic secure connection enforcement
- **Certificate Auto-renewal**: Maintenance-free SSL management

### Monitoring & Maintenance
- **Health Monitoring**: System status checking script
- **Automated Backups**: Daily database and file backups
- **Log Management**: Structured logging with rotation
- **Fail2ban Protection**: Automatic intrusion prevention

### Production Optimizations
- **Browser Caching**: 30-day static asset caching
- **Connection Optimization**: HTTP/1.1 with keep-alive
- **Memory Management**: Efficient resource utilization
- **Process Monitoring**: PM2 cluster mode support

## Quick Deployment Summary

1. **Upload & Install**: Single command deployment
2. **Configure Domain**: Simple nginx configuration edit
3. **Setup SSL**: Automated certificate installation
4. **Go Live**: Production-ready in minutes

The nginx setup provides enterprise-grade performance and security for your crypto airdrop platform.

## Environment Variables

Key environment variables (automatically set during installation):

- `NODE_ENV=production`
- `PORT=3000`
- `DATABASE_URL=postgresql://user:pass@localhost:5432/crypto_airdrop`
- `SESSION_SECRET=random_secret`

## Default Admin Access

After installation, access the application and register the first user - they will automatically become an admin.

## File Structure

```
/var/www/crypto-airdrop/
├── client/               # React frontend
├── server/               # Express backend
├── shared/               # Shared schemas and types
├── db/                   # Database configuration
├── public/               # Static files and uploads
├── dist/                 # Built application
├── ecosystem.config.js   # PM2 configuration
├── update.sh            # Update script
├── backup.sh            # Backup script
└── .env                 # Environment variables
```

## Troubleshooting

### Application Won't Start

```bash
pm2 logs crypto-airdrop  # Check logs
pm2 restart crypto-airdrop
```

### Database Connection Issues

```bash
sudo systemctl status postgresql
sudo -u postgres psql -c "\l"  # List databases
```

### Apache Issues

```bash
sudo systemctl status apache2
sudo apache2ctl configtest
sudo tail -f /var/log/apache2/error.log
```

### File Permissions

```bash
sudo chown -R www-data:www-data /var/www/crypto-airdrop
sudo chmod -R 755 /var/www/crypto-airdrop
```

## Support

For technical support or questions about deployment, check the application logs and Apache error logs first. The application includes comprehensive error handling and logging.