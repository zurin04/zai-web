#!/bin/bash

# Quick Start Script for Crypto Airdrop Platform
# Run this after the main installation to start the application

set -e

APP_DIR="/var/www/crypto-airdrop"

echo "Starting Crypto Airdrop Platform..."

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "Changing to application directory..."
    cd $APP_DIR
fi

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "Creating environment file from template..."
    cp .env.example .env
    echo "Please edit .env file with your configuration before continuing."
    echo "Run: nano .env"
    exit 1
fi

# Install dependencies if not already installed
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

# Build application
echo "Building application..."
npm run build

# Run database migrations
echo "Setting up database..."
npm run db:push

# Seed database with initial data
echo "Seeding database..."
npm run db:seed

# Start with PM2
echo "Starting application with PM2..."
pm2 start ecosystem.config.js
pm2 save

echo ""
echo "Application started successfully!"
echo "Access your app at: http://localhost:3000"
echo ""
echo "Management commands:"
echo "  pm2 status - Check status"
echo "  pm2 logs crypto-airdrop - View logs"
echo "  pm2 restart crypto-airdrop - Restart app"
echo ""